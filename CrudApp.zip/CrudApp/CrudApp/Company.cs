﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CrudApp
{
    public partial class Company : Form
    {
        public Company()
        {
            InitializeComponent();
        }

        private void companyDataBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.companyDataBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.ds_CompanyProduct);

        }

        private void Company_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'ds_CompanyProduct.ProductInfo' table. You can move, or remove it, as needed.
            this.productInfoTableAdapter.Fill(this.ds_CompanyProduct.ProductInfo);
            // TODO: This line of code loads data into the 'ds_CompanyProduct.CompanyData' table. You can move, or remove it, as needed.
            this.companyDataTableAdapter.Fill(this.ds_CompanyProduct.CompanyData);

        }
    }
}
